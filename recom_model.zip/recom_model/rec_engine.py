import pandas as pd
from math import radians, sin, cos, asin, sqrt

def haversine(lat1, lon1, lat2, lon2):
    R = 6371
    dlat = radians(lat2 - lat1)
    dlon = radians(lon2 - lon1)
    a = sin(dlat / 2) ** 2 + cos(radians(lat1)) * cos(radians(lat2)) * sin(dlon / 2) ** 2
    return 2 * R * asin(sqrt(a))

df = pd.read_excel("charging_stations.xlsx")    # pip install pandas

df["capacity"] = (df["capacity"].astype(str).str.lower().str.replace("kw", "", regex=False).str.strip())
df["capacity"] = pd.to_numeric(df["capacity"], errors="coerce")

stations = {}

for _, row in df.iterrows():
    stations[row["uid"]] = {
        "name": row["name"],       
        "latitude": row["latitude"],
        "longitude": row["longitude"],
        "distance": None,
        "charging_speed": row["capacity"],
        "price": row["cost_per_unit"],
        "availability": row["available"],
        #charger_type,rating
    }

user = {
    "latitude": float(input("Your latitude: ")),
    "longitude": float(input("Your longitude: ")),
    "battery": float(input("Battery percentage: ")),
    "min_charging_speed": float(input("Minimum charging speed you prefer (kW): "))
}
print(user)

for station in stations.values():
    station["distance"] = haversine(
        user["latitude"], user["longitude"],
        station["latitude"], station["longitude"]
    )

candidates = {}

for uid, station in stations.items():
    if station["availability"] > 0 and station["charging_speed"] >= user["min_charging_speed"]:
        candidates[uid] = station

if len(candidates) == 0:
    print("No compatible and available station found.")
    exit()

distances = [s["distance"] for s in candidates.values()]
min_dist = min(distances)
max_dist = max(distances)

max_speed = max(s["charging_speed"] for s in candidates.values())

results = []

for uid, station in candidates.items():
    # distance score: nearest=1
    if max_dist == min_dist:
        distance_score = 1
    else:
        distance_score = (max_dist - station["distance"]) / (max_dist - min_dist)   #range - .5 to 1

    speed_score = station["charging_speed"] / max_speed     #max=1, min=0

    final_score = 0.5 * distance_score + 0.5 * speed_score

    results.append({
        "name": station["name"],
        "distance": station["distance"],
        "speed": station["charging_speed"],
        "score": final_score
    })

results.sort(key=lambda x: x["score"], reverse=True)

print("\nCharging Station Recommendations:\n")
for i, r in enumerate(results, 1):
    print(f"{i}. {r['name']} | {r['distance']:.1f} km | {r['speed']} kW") #| score {r['score']:.3f}")